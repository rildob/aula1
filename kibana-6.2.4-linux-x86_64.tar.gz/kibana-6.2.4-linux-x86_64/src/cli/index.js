'use strict';

require('../babel-register');
require('./cli');
