'use strict';

require('script-loader!../node_modules/sinon/pkg/sinon.js');
module.exports = window.sinon;
